import pandas as pd
import win32com.client as win32
#biblioteca pra enviar email
#junta o python com excel o pandas/os 'as' e pra dar um novo nome para a biblioteca

#importar base de dados

tabela_vendas = pd.read_excel('Vendas.xlsx')

#ler o excel


#visualizar base de dados
pd.set_option('display.max_columns',None) #ver todas a colunas
print(tabela_vendas)

#faturamento por loja
#agrupa todas as lojas e soma e filtra so a cluna de faturamento

faturamento=tabela_vendas[['ID Loja','Valor Final']].groupby('ID Loja').sum()
print(faturamento)

#quantidade de produtos vendidos por loja
quantidade1=tabela_vendas[['ID Loja','Quantidade']].groupby('ID Loja').sum()
print(quantidade1)

#ticket medio de produtos de cada loja
#O ticket medio e a tabela de faturamento divideda pela de quantidade

ticket_medio=(faturamento['Valor Final']/quantidade1['Quantidade']).to_frame()
ticket_medio=ticket_medio.rename(columns={0:'Ticket Medio'})
print(ticket_medio)
#to_frame transforma em coluna

#enviar um relatorio por email
outlook = win32.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = 'brendaemanuelledps80@gmail.com'
mail.Subject = 'Relatorio de vendas por loja'
mail.Body = 'Message body'
mail.HTMLBody = f'''
<p>Prezados, segue o relatorio de vendas:</p>

<p>Faturamento:</p>
{faturamento.to_html(formatters={'Valor Final': 'R${:,.2f}'.format})}

<p>Quantodade:</p>
{quantidade1.to_html()}

<p>Ticket medio de produtos de cada loja</p>
{ticket_medio.to_html(formatters={'Ticket Medio': 'R${:,.2f}'.format})}

<p>Qualquer duvidas pode entrar em contato.</p>
<p>Atenciosamente:Brenda</p>

''' 

#escrever um texto com mais de uma linha
#.to_html() transforma a tabela em html

mail.send()
print("Email enviado")